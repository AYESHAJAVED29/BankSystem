package banksystem;

import java.util.Scanner;

public class BankSystem {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nBank Management System");
            System.out.println("1. Create Account");
            System.out.println("2. Delete Account");
            System.out.println("3. Deposit");
            System.out.println("4. Withdraw");
            System.out.println("5. Transfer");
            System.out.println("6. Show All Accounts");
            System.out.println("7. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    while (true) {
                        try {
                            System.out.print("Enter account number (6 digits): ");
                            String accNum = scanner.nextLine();

                            System.out.print("Enter name: ");
                            String name = scanner.nextLine();

                            System.out.print("Enter initial balance: ");
                            double balance = scanner.nextDouble();
                            scanner.nextLine(); 

                            System.out.print("Enter CNIC (13 digits): ");
                            String cnic = scanner.nextLine();

                            if (cnic.length() != 13) {
                                System.out.println("CNIC must be 13 digits long. Please try again.");
                                continue;
                            }

                            if (bank.accountExists(accNum)) {
                                System.out.println("Account number already exists. Please try again.");
                                continue;
                            }

                            if (bank.cnicExists(cnic)) {
                                System.out.println("CNIC already exists. Please try again.");
                                continue;
                            }

                            bank.createAccount(accNum, name, balance, cnic);
                            System.out.println("Account created successfully.");
                            break;
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.out.println("Please try again.");
                        }
                    }
                    break;

                case 2:
                    while (true) {
                        try {
                            System.out.print("Enter account number to delete: ");
                            String accNo = scanner.nextLine();
                            bank.deleteAccount(accNo);
                            System.out.println("Account deleted successfully.");
                            break;
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.out.println("Please try again.");
                        }
                    }
                    break;

                case 3:
                    while (true) {
                        try {
                            System.out.print("Enter account number for deposit: ");
                            String accNo = scanner.nextLine();

                            double depositAmount;
                            while (true) {
                                System.out.print("Enter amount to deposit: ");
                                depositAmount = scanner.nextDouble();
                                scanner.nextLine(); 

                                if (depositAmount >= 0) {
                                    break;
                                } else {
                                    System.out.println("Deposit amount must be non-negative. Please try again.");
                                }
                            }

                            bank.deposit(accNo, depositAmount);
                            System.out.println("Deposit successful.");
                            break;
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.out.println("Please try again.");
                        }
                    }
                    break;

                case 4:
                    while (true) {
                        try {
                            System.out.print("Enter account number for withdrawal: ");
                            String accNo = scanner.nextLine();

                            double withdrawAmount;
                            while (true) {
                                System.out.print("Enter amount to withdraw: ");
                                withdrawAmount = scanner.nextDouble();
                                scanner.nextLine(); 
                                if (withdrawAmount >= 0) {
                                    break;
                                } else {
                                    System.out.println("Withdrawal amount must be non-negative. Please try again.");
                                }
                            }
                            bank.withdraw(accNo, withdrawAmount);
                            System.out.println("Withdrawal successful.");
                            break;
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.out.println("Please try again.");
                        }
                    }
                    break;

                case 5:
                    while (true) {
                        try {
                            System.out.print("Enter source account number: ");
                            String fromAccNo = scanner.nextLine();

                            System.out.print("Enter destination account number: ");
                            String toAccNo = scanner.nextLine();

                            double transferAmount;
                            while (true) {
                                System.out.print("Enter amount to transfer: ");
                                transferAmount = scanner.nextDouble();
                                scanner.nextLine(); 
                                if (transferAmount >= 0) {
                                    break;
                                } else {
                                    System.out.println("Transfer amount must be non-negative. Please try again.");
                                }
                            }
                            bank.transfer(fromAccNo, toAccNo, transferAmount);
                            System.out.println("Transfer successful.");
                            break;
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.out.println("Please try again.");
                        }
                    }
                    break;

                case 6:
                    bank.showAllAccounts();
                    break;

                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
