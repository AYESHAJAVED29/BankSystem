
package banksystem;

public class Account {
   private String accNum; 
    private String name;
    private double balance;
    private String cnic; 

    public Account(String accNum, String name, double balance, String cnic) {
        this.accNum = accNum;
        this.name = name;
        this.balance = balance;
        this.cnic = cnic;
    }

    public String getAccNum() {
        return accNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public String getCnic() {
        return cnic;
    }

    public void deposit(double amount) {
        this.balance += amount;
    }

    public void withdraw(double amount) throws Exception {
        if (balance >= amount) {
            this.balance -= amount;
        } else {
            throw new Exception("Insufficient Balance");
        }
    }

    @Override
    public String toString() {
        return accNum + "," + name + "," + balance + "," + cnic;
    }

    public static Account fromString(String accountData) {
        String[] parts = accountData.split(",");
        String accNum = parts[0];
        String name = parts[1];
        double balance = Double.parseDouble(parts[2]);
        String cnic = parts[3];
        return new Account(accNum, name, balance, cnic);
    }
}