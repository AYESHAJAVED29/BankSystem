package banksystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Bank {
    private List<Account> accounts;
    private final String filePath = "C:\\Users\\ayesh\\OneDrive\\Desktop\\java\\BankSystem\\accounts.txt";
    private final Scanner scanner = new Scanner(System.in);

    public Bank() {
        accounts = new ArrayList<>();
        loadAccounts();
    }

    // Create Account
    public void createAccount(String accNum, String name, double balance, String cnic) {
        Account account = new Account(accNum, name, balance, cnic);
        accounts.add(account);
        saveAccounts(); 
    }

    // Delete Account
    public void deleteAccount(String accNum) throws Exception {
        Account acc = findAccountByNumber(accNum);
        if (acc != null) {
            accounts.remove(acc);
            saveAccounts(); 
        } else {
            throw new Exception("Account not found");
        }
    }

    // Find Account
    public Account findAccountByNumber(String accNum) throws Exception {
        for (Account account : accounts) {
            if (account.getAccNum().equals(accNum)) {
                return account;
            }
        }
        throw new Exception("Account not found");
    }

    // Deposit
    public void deposit(String accNum, double amount) throws Exception {
        Account acc = findAccountByNumber(accNum);
        acc.deposit(amount);
        saveAccounts();
    }

    // Withdraw
    public void withdraw(String accNum, double amount) throws Exception {
        Account acc = findAccountByNumber(accNum);    
        while (amount > acc.getBalance()) {
            System.out.println("You do not have enough balance. Your current balance is: " + acc.getBalance());
            System.out.print("Please enter a valid amount to withdraw: ");
            amount = scanner.nextDouble();
        }
        acc.withdraw(amount);
        saveAccounts();
        System.out.println("Withdrawal of $" + amount + " was successful.");
    }

    // Display All Accounts
    public void showAllAccounts() {
        accounts.forEach(System.out::println);
    }

    private void saveAccounts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Account account : accounts) {
                writer.write(account.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving accounts: " + e.getMessage());
        }
    }

    // Transfer
    public void transfer(String fromAccNo, String toAccNo, double amount) throws Exception {
        Account sender = findAccountByNumber(fromAccNo);
        Account recipient = findAccountByNumber(toAccNo);
        while (amount > sender.getBalance()) {
            System.out.println("Sender does not have enough balance. Current balance: " + sender.getBalance());
            System.out.print("Please enter a valid amount to transfer: ");
            amount = scanner.nextDouble();
        }
        sender.withdraw(amount);
        recipient.deposit(amount);
        saveAccounts();
        System.out.println("Transfer of $" + amount + " from Account " + fromAccNo + " to Account " + toAccNo + " was successful.");
    }

    public void loadAccounts() {
        File file = new File(filePath);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    accounts.add(Account.fromString(line));
                }
            } catch (IOException e) {
                System.out.println("Error loading accounts: " + e.getMessage());
            }
        }
    }

    public boolean cnicExists(String cnic) {
        for (Account account : accounts) {
            if (account.getCnic().equals(cnic)) {
                return true;
            }
        }
        return false;
    }

    public boolean accountExists(String accNum) {
        for (Account account : accounts) {
            if (account.getAccNum().equals(accNum)) {
                return true;
            }
        }
        return false;
    }
}
